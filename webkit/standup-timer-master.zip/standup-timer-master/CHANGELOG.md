## ChangeLog

### Version 1.4
- Let the user adjust the media volume when the timer is running

### Version 1.3 
- Allow a meeting with only 1 participant
- Removed unnecessary Quit menu item

### Version 1.2 
- Added support for meetings of any length
- Added support for meetings with any number of participants

### Version 1.1 
- Added support for teams
- Added support for tracking meeting statistics on a per team basis

### Version 1.0 
- Initial release

